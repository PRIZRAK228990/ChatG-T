// MYCELIUM: Spore × Biomancy × Blood Magic
// Minecraft 1.20.1 Forge / KubeJS 6
// Эти предметы являются промежуточными компонентами интеграции.
StartupEvents.registry('item', event => {
  event.create('hematic_living_core').texture('kubejs:item/hematic_living_core').maxStackSize(16)
  event.create('hematic_amalgamated_heart').texture('kubejs:item/hematic_amalgamated_heart').maxStackSize(16)
  event.create('spore_preform_assassin_recipe_surgery_a').texture('kubejs:item/spore_preform_assassin_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_assassin_recipe_surgery_b').texture('kubejs:item/spore_preform_assassin_recipe_surgery_b').maxStackSize(16)
  event.create('spore_preform_bileblaster_recipe_surgery_a').texture('kubejs:item/spore_preform_bileblaster_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_bileblaster_recipe_surgery_b').texture('kubejs:item/spore_preform_bileblaster_recipe_surgery_b').maxStackSize(16)
  event.create('spore_preform_combat_pickaxe_recipe_surgery_a').texture('kubejs:item/spore_preform_combat_pickaxe_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_flesh_chestplate_recipe_surgery_a').texture('kubejs:item/spore_preform_flesh_chestplate_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_fungal_burger_a').texture('kubejs:item/spore_preform_fungal_burger_a').maxStackSize(16)
  event.create('spore_preform_greatsword_recipe_surgery_a').texture('kubejs:item/spore_preform_greatsword_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_mistmaker_recipe_surgery_a').texture('kubejs:item/spore_preform_mistmaker_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_mistmaker_recipe_surgery_b').texture('kubejs:item/spore_preform_mistmaker_recipe_surgery_b').maxStackSize(16)
  event.create('spore_preform_rapier_recipe_surgery_a').texture('kubejs:item/spore_preform_rapier_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_terroriser_recipe_surgery_a').texture('kubejs:item/spore_preform_terroriser_recipe_surgery_a').maxStackSize(16)
  event.create('spore_preform_terroriser_recipe_surgery_b').texture('kubejs:item/spore_preform_terroriser_recipe_surgery_b').maxStackSize(16)
})
